INSERT INTO directors (first_name, last_name, country)
VALUES ("John", "Lasseter", "USA");

INSERT INTO directors (first_name, last_name, country)
VALUES ("Brad", "Bird", "USA");

INSERT INTO directors (first_name, last_name, country)
VALUES ("Jodie", "Foster", "USA"); 

INSERT INTO directors (first_name, last_name, country)
VALUES ("Ang", "Lee", "Taiwan"); 

insert into directors (first_name, last_name, country)
values ("Alfonso", "Cuarón", "Mexico");

insert into directors (first_name, last_name, country)
values ("Guillermo", "del Toro", "Mexico");

insert into directors (first_name, last_name, country)
values ("Peter", "Jackson", "New Zealand");

insert into directors (first_name, last_name, country)
values ("Ava", "DuVernay", "USA");

insert into directors (first_name, last_name, country)
values ("Patty", "Jenkins", "USA");

insert into directors (first_name, last_name, country)
values ("Haifaa", "al-Mansour", "Saudi Arabia");

INSERT INTO movies (title, year_released, director_id)
VALUES ("Toy Story", 1995, 1);

INSERT INTO movies (title, year_released, director_id)
VALUES ("The Incredibles", 2004, 2);

INSERT INTO movies (title, year_released, director_id)
VALUES ("Money Monster", 2016, 3);

INSERT INTO movies (title, year_released, director_id)
VALUES ("A Bug's Life", 1998, 1);

INSERT INTO movies (title, year_released, director_id)
VALUES ("Crouching Tiger, Hidden Dragon", 2000, 4);

INSERT INTO movies (title, year_released, director_id)
VALUES ("Harry Potter and the Prisoner of Azkaban", 2004, 5);

INSERT INTO movies (title, year_released, director_id)
VALUES ("Little Man Tate", 1991, 3);

INSERT INTO movies (title, year_released, director_id)
VALUES ("Roma", 2018, 5);

INSERT INTO movies (title, year_released, director_id)
VALUES ("The Perfect Candidate", 2019, 10);

INSERT INTO movies (title, year_released, director_id)
VALUES ("The Shape of Water", 2017, 6);

INSERT INTO movies (title, year_released, director_id)
VALUES ("The Lord of the Rings: The Return of the King", 2003, 7);

INSERT INTO movies (title, year_released, director_id)
VALUES ("A Wrinke in Time", 2018, 8);

INSERT INTO movies (title, year_released, director_id)
VALUES ("Wonder Woman", 2017, 9);

INSERT INTO movies (title, year_released, director_id)
VALUES ("Ratatouille", 2007, 2);

INSERT INTO movies (title, year_released, director_id)
VALUES ("Mary Shelley", 2017, 10);

INSERT INTO movies (title, year_released, director_id)
VALUES ("Selma", 2014, 8);